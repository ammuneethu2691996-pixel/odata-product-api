# OData V4 Product API — VPS deployment

This bundle runs the existing Node.js OData service in Docker and puts Caddy in front of it for HTTPS. The product JSON file is mounted read-only from the host and is not copied into the API image.

## Requirements

- A Linux VPS (Ubuntu 24.04 LTS recommended) with a public IPv4 address.
- Start with at least 2 GB RAM and enough free disk for the 119 MB dataset, Docker images, logs, and backups. Load-test and resize if necessary.
- A domain or subdomain you control, for example `products-api.example.com`.
- Docker Engine and the Docker Compose plugin.
- In the cloud firewall and host firewall, allow inbound TCP 22 from your trusted admin IP where possible, plus TCP 80 and TCP 443. Do not expose port 4004 publicly.

## 1. Prepare the VPS

Install Docker Engine and the Docker Compose plugin using the official Docker instructions for your Ubuntu version. Create a deployment directory such as `/opt/odata-product-api`, and copy the contents of this folder there, including `product_master_330k.json`.

For example, from your workstation (replace `VPS_IP` and local paths):

```bash
scp -r API user@VPS_IP:/tmp/odata-product-api
ssh user@VPS_IP
sudo mkdir -p /opt/odata-product-api
sudo cp -a /tmp/odata-product-api/. /opt/odata-product-api/
cd /opt/odata-product-api
```

Use an administrative account and appropriate file permissions. Keep the dataset read-only to the API process where practical.

## 2. Configure DNS and credentials

At your DNS provider, create an A record for your chosen subdomain pointing to the VPS public IPv4 address. If you publish an AAAA record, it must point to a working IPv6 address on this server.

Create the environment file and edit it:

```bash
cp .env.example .env
nano .env
```

Set `DOMAIN` to the exact public hostname and replace both credential values. Generate a long random password, for example with `openssl rand -base64 36`. Protect the file:

```bash
chmod 600 .env
```

Do not share credentials in chat, source control, screenshots, or logs. Basic Authentication must only be used over HTTPS. Use separate credentials per client if you need individual revocation or auditing; this starter uses one shared credential pair.

## 3. Start the API

Ensure DNS has propagated and inbound ports 80 and 443 are open. Then run:

```bash
docker compose up -d --build
docker compose ps
docker compose logs --tail=100 api caddy
```

Caddy will request and renew the public TLS certificate automatically when DNS and ports are correct. Certificate issuance may take a short time. The API container is not published directly to the Internet; only Caddy publishes ports 80 and 443.

## 4. Test it

Set the hostname and enter the username/password you configured in `.env`:

```bash
export API_BASE='https://products-api.example.com/v4/StandaloneService'
export API_USERNAME='your-username'
read -s API_PASSWORD
export API_PASSWORD

# Liveness check (no data is returned)
curl -i "https://products-api.example.com/healthz"

# Must return 401 without credentials
curl -i "$API_BASE/"

# Service document; must return 200 with credentials
curl -i -u "$API_USERNAME:$API_PASSWORD" "$API_BASE/"

# OData metadata XML
curl -i -u "$API_USERNAME:$API_PASSWORD" "$API_BASE/\$metadata"

# First 10 products
curl -i -u "$API_USERNAME:$API_PASSWORD" "$API_BASE/VG_PRODUCT_API?\$top=10"

# Filter example (replace MAT001 with a real Material_Group value)
curl -G -u "$API_USERNAME:$API_PASSWORD" \
  --data-urlencode "\$filter=Material_Group eq 'MAT001'" \
  "$API_BASE/VG_PRODUCT_API"
```

The metadata and collection response context URLs should use the public `https://` hostname, not `localhost` or the internal container name.

## 5. Use from external clients

- Base URL: `https://products-api.example.com/v4/StandaloneService/`
- Metadata URL: `https://products-api.example.com/v4/StandaloneService/$metadata`
- Entity set: `VG_PRODUCT_API`
- Authentication: Basic Authentication, using the username and password stored in `.env`.
- TLS certificate: public CA certificate managed by Caddy; clients should validate it normally. Do not disable certificate validation.

In Postman, choose Authorization → Basic Auth. In Boomi, configure the HTTP Client connection/operation to call the HTTPS URL and provide Basic Authentication. For SAP, use the relevant HTTP/OData consumer configuration and provide the same endpoint and credentials. Exact field names vary by product/version.

## Important API behavior and scale considerations

- The service is read-only. POST, PUT, PATCH, and DELETE are rejected.
- `$skip`, `$orderby`, and `$count=true` are intentionally rejected per the service metadata.
- `$top` is supported. Use it for smoke tests and small extracts. With `$skip` disabled, this service does not offer conventional page-by-page extraction of the full dataset.
- A request without `$top` can return all 330,000 records. Avoid this with concurrent clients; the response may be very large even with compression. For sustained multi-client production use, consider adding a stable key-based continuation/filter strategy or moving the dataset into a database with indexed queries.
- The current filter implementation supports only a simple `Property eq 'value'` expression. It is not a complete OData parser.
- Protect the VPS with security updates, firewall rules, monitoring, and backups. Do not expose Docker's API or port 4004 publicly.

## Updating/restarting

```bash
cd /opt/odata-product-api
docker compose up -d --build
docker compose logs -f --tail=100 api caddy
```

Back up `product_master_330k.json` and the `.env` file securely. Caddy's named volumes retain certificate state across container restarts.
