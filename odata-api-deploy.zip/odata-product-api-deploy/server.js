const express = require('express');
const fs = require('fs');
const compression = require('compression');
const crypto = require('crypto');

const app = express();
app.set('trust proxy', 1); // The API container is reachable only through Caddy.
app.use(compression());
app.use(express.json({ limit: '1mb' }));

// Require credentials from environment variables; never hardcode secrets.
const API_USERNAME = process.env.API_USERNAME;
const API_PASSWORD = process.env.API_PASSWORD;
if (!API_USERNAME || !API_PASSWORD) {
    console.error('Missing API_USERNAME or API_PASSWORD environment variables.');
    process.exit(1);
}

function safeEqual(a, b) {
    const aa = Buffer.from(String(a));
    const bb = Buffer.from(String(b));
    return aa.length === bb.length && crypto.timingSafeEqual(aa, bb);
}

function requireBasicAuth(req, res, next) {
    const header = req.get('authorization') || '';
    const match = header.match(/^Basic\s+(.+)$/i);
    if (!match) return askForCredentials(res);
    let decoded;
    try { decoded = Buffer.from(match[1], 'base64').toString('utf8'); }
    catch (_) { return askForCredentials(res); }
    const separator = decoded.indexOf(':');
    if (separator < 0) return askForCredentials(res);
    const username = decoded.slice(0, separator);
    const password = decoded.slice(separator + 1);
    if (!safeEqual(username, API_USERNAME) || !safeEqual(password, API_PASSWORD)) {
        return askForCredentials(res);
    }
    next();
}

function askForCredentials(res) {
    res.set('WWW-Authenticate', 'Basic realm=\"OData Product API\", charset=\"UTF-8\"');
    return res.status(401).json({ error: { code: 'Unauthorized', message: 'Valid Basic Authentication credentials are required.' } });
}

// A minimal liveness endpoint for deployment checks; it does not expose data.
app.get('/healthz', (req, res) => res.status(200).json({ status: 'ok' }));
app.use('/v4/StandaloneService', requireBasicAuth);

function serviceBaseUrl(req) {
    return `${req.protocol}://${req.get('host')}/v4/StandaloneService/`;
}

const PORT = process.env.PORT || 4004;
const DATA_FILE = './product_master_330k.json';

// Load 330,000 records into memory or stream-index them on startup
console.log('Loading product dataset into memory...');
let products = [];
try {
    const rawData = fs.readFileSync(DATA_FILE, 'utf-8');
    products = JSON.parse(rawData);
    console.log(`Successfully loaded ${products.length} product records.`);
} catch (error) {
    console.error('Error loading product_master_330k.json:', error.message);
    process.exit(1);
}

// ==========================================
// 1. OData V4 Service Metadata Document ($metadata)
// ==========================================
app.get('/v4/StandaloneService/$metadata', (req, res) => {
    res.setHeader('Content-Type', 'application/xml; charset=utf-8');
    res.send(`<?xml version="1.0" encoding="utf-8"?>
<edmx:Edmx Version="4.0" xmlns:edmx="http://docs.oasis-open.org/odata/ns/edmx">
    <edmx:Reference Uri="https://oasis-tcs.github.io/odata-vocabularies/vocabularies/Org.OData.Capabilities.V1.xml">
        <edmx:Include Alias="Capabilities" Namespace="Org.OData.Capabilities.V1"/>
    </edmx:Reference>
    <edmx:Reference Uri="https://sap.github.io/odata-vocabularies/vocabularies/Common.xml">
        <edmx:Include Alias="Common" Namespace="com.sap.vocabularies.Common.v1"/>
    </edmx:Reference>
    <edmx:DataServices>
        <Schema Namespace="StandaloneService" xmlns="http://docs.oasis-open.org/odata/ns/edm">
            <EntityContainer Name="EntityContainer">
                <EntitySet Name="VG_PRODUCT_API" EntityType="StandaloneService.VG_PRODUCT_API"/>
            </EntityContainer>
            <EntityType Name="VG_PRODUCT_API">
                <Key><PropertyRef Name="Article_Number"/></Key>
                <Property Name="Article_Number" Type="Edm.String" MaxLength="40"/>
                <Property Name="Material_Group" Type="Edm.String" MaxLength="9"/>
                <Property Name="Gross_weight" Type="Edm.Decimal" Precision="13" Scale="3"/>
                <Property Name="Net_Weight" Type="Edm.Decimal" Precision="13" Scale="3"/>
                <Property Name="Unit_of_Weight" Type="Edm.String" MaxLength="3"/>
                <Property Name="GTIN__EAN_Barcode" Type="Edm.String" MaxLength="18"/>
                <Property Name="Main_Size" Type="Edm.String" MaxLength="18"/>
                <Property Name="selling_size_range" Type="Edm.String" MaxLength="40"/>
                <Property Name="Article_Description" Type="Edm.String" MaxLength="40"/>
                <Property Name="Product_Delta_Pointer" Type="Edm.DateTimeOffset" Precision="7"/>
                <Property Name="Article_Category" Type="Edm.String" MaxLength="2"/>
            </EntityType>
            <Annotations Target="StandaloneService.EntityContainer/VG_PRODUCT_API">
                <Annotation Term="Capabilities.SkipSupported" Bool="false"/>
                <Annotation Term="Capabilities.SortRestrictions">
                    <Record Type="Capabilities.SortRestrictionsType">
                        <PropertyValue Property="Sortable" Bool="false"/>
                    </Record>
                </Annotation>
                <Annotation Term="Capabilities.CountRestrictions">
                    <Record Type="Capabilities.CountRestrictionsType">
                        <PropertyValue Property="Countable" Bool="false"/>
                    </Record>
                </Annotation>
                <Annotation Term="Capabilities.DeleteRestrictions">
                    <Record Type="Capabilities.DeleteRestrictionsType">
                        <PropertyValue Property="Deletable" Bool="false"/>
                    </Record>
                </Annotation>
                <Annotation Term="Capabilities.InsertRestrictions">
                    <Record Type="Capabilities.InsertRestrictionsType">
                        <PropertyValue Property="Insertable" Bool="false"/>
                    </Record>
                </Annotation>
                <Annotation Term="Capabilities.UpdateRestrictions">
                    <Record Type="Capabilities.UpdateRestrictionsType">
                        <PropertyValue Property="Updatable" Bool="false"/>
                    </Record>
                </Annotation>
            </Annotations>
        </Schema>
    </edmx:DataServices>
</Edmx>`);
});

// ==========================================
// 2. Service Document Root
// ==========================================
app.get('/v4/StandaloneService/', (req, res) => {
    res.json({
        "@odata.context": serviceBaseUrl(req) + "$metadata",
        "value": [
            {
                "name": "VG_PRODUCT_API",
                "kind": "EntitySet",
                "url": "VG_PRODUCT_API"
            }
        ]
    });
});

// ==========================================
// 3. EntitySet API Endpoints (Enforcing Restrictions)
// ==========================================

// GET Collection: VG_PRODUCT_API
app.get('/v4/StandaloneService/VG_PRODUCT_API', (req, res) => {
    let results = products;

    // Enforce Skip restriction: SkipSupported = false
    if (req.query.$skip !== undefined) {
        return res.status(403).json({
            error: {
                code: "Forbidden",
                message: "Skip operations are not supported on this entity set as per metadata restrictions (SkipSupported=false)."
            }
        });
    }

    // Enforce Sort restriction: Sortable = false
    if (req.query.$orderby !== undefined) {
        return res.status(403).json({
            error: {
                code: "Forbidden",
                message: "Sorting is not supported on this entity set as per metadata restrictions (Sortable=false)."
            }
        });
    }

    // Enforce Count restriction: Countable = false
    if (req.query.$count === 'true' || req.path.endsWith('/$count')) {
        return res.status(403).json({
            error: {
                code: "Forbidden",
                message: "Counting is not supported on this entity set as per metadata restrictions (Countable=false)."
            }
        });
    }

    // Basic MultiValue filter support (e.g., $filter=Material_Group eq 'MAT001')
    if (req.query.$filter) {
        // Simple evaluation pattern matching typical OData eq filters
        const filterStr = req.query.$filter.trim();
        const eqMatch = filterStr.match(/^(\w+)\s+eq\s+'([^']+)'$/i);
        if (eqMatch) {
            const [, prop, val] = eqMatch;
            results = results.filter(item => String(item[prop]) === val);
        }
    }

    // Handle $top pagination
    if (req.query.$top) {
        const topVal = parseInt(req.query.$top, 10);
        if (!isNaN(topVal)) {
            results = results.slice(0, topVal);
        }
    }

    res.json({
        "@odata.context": serviceBaseUrl(req) + "$metadata#VG_PRODUCT_API",
        "value": results
    });
});

// Enforce Write Restrictions: Insertable = false
app.post('/v4/StandaloneService/VG_PRODUCT_API', (req, res) => {
    res.status(405).json({
        error: { code: "MethodNotAllowed", message: "Insert operations are disabled (Insertable=false)." }
    });
});

// Enforce Update Restrictions: Updatable = false
app.put(/^\/v4\/StandaloneService\/VG_PRODUCT_API\(.+\)$/, (req, res) => {
    res.status(405).json({
        error: { code: "MethodNotAllowed", message: "Update operations are disabled (Updatable=false)." }
    });
});
app.patch(/^\/v4\/StandaloneService\/VG_PRODUCT_API\(.+\)$/, (req, res) => {
    res.status(405).json({
        error: { code: "MethodNotAllowed", message: "Update operations are disabled (Updatable=false)." }
    });
});

// Enforce Delete Restrictions: Deletable = false
app.delete(/^\/v4\/StandaloneService\/VG_PRODUCT_API\(.+\)$/, (req, res) => {
    res.status(405).json({
        error: { code: "MethodNotAllowed", message: "Delete operations are disabled (Deletable=false)." }
    });
});

// Start Server
app.listen(PORT, '0.0.0.0', () => {
    console.log(`OData V4 API listening on port ${PORT}; public access should be provided only through HTTPS reverse proxy.`);
});